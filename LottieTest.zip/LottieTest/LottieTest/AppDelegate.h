//
//  AppDelegate.h
//  LottieTest
//
//  Created by 张雨帆 on 2020/6/23.
//  Copyright © 2020 张雨帆. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>


@end

